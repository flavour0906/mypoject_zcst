# 校园二手交易平台

一个基于 Spring MVC + MyBatis 的校园二手交易平台，支持用户注册、登录、商品发布、购买等功能。

## 项目特性

- 🏫 **校园特色**：专为校园用户设计的二手交易平台
- 👥 **用户管理**：支持用户注册、登录、个人信息管理
- 📦 **商品管理**：支持商品发布、编辑、下架、分类管理
- 🛒 **订单系统**：完整的订单流程，从下单到收货
- 🔐 **安全认证**：密码加密、登录拦截器
- 📱 **响应式设计**：支持PC和移动端访问

## 技术栈

- **后端框架**：Spring MVC 5.3.30
- **持久层框架**：MyBatis 3.5.13
- **数据库**：MySQL 8.0
- **连接池**：HikariCP 4.0.3
- **前端框架**：Bootstrap 5.1.3
- **构建工具**：Maven 3.8.1
- **服务器**：Tomcat 8.5+

## 项目结构

```
campus-market/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   ├── controller/          # 控制器层
│   │   │   ├── service/             # 服务层
│   │   │   ├── dao/                 # 数据访问层
│   │   │   └── entity/              # 实体类
│   │   ├── resources/
│   │   │   ├── mapper/              # MyBatis映射文件
│   │   │   ├── applicationContext.xml  # Spring配置
│   │   │   ├── spring-mvc.xml       # Spring MVC配置
│   │   │   └── database.properties  # 数据库配置
│   │   └── webapp/
│   │       ├── WEB-INF/
│   │       │   ├── views/           # JSP视图文件
│   │       │   └── web.xml          # Web应用配置
│   │       └── index.jsp            # 首页
│   └── test/                        # 测试目录
├── database/                        # 数据库脚本
├── pom.xml                          # Maven配置
└── README.md                        # 项目说明
```

## 快速开始

### 环境要求

- JDK 1.8+
- Maven 3.6+
- MySQL 8.0+
- Tomcat 8.5+

### 安装步骤

1. **克隆项目**
   ```bash
   git clone https://github.com/your-username/campus-market.git
   cd campus-market
   ```

2. **配置数据库**
   - 创建MySQL数据库
   - 执行 `database/campus_trading_schema.sql` 脚本
   - 修改 `src/main/resources/database.properties` 中的数据库连接信息

3. **编译项目**
   ```bash
   mvn clean compile
   ```

4. **运行项目**
   ```bash
   mvn tomcat7:run
   ```

5. **访问应用**
   打开浏览器访问：http://localhost:8080/campus-market

### 默认账户

- **管理员账户**：admin / admin123
- **普通用户**：user1 / user123

## 功能模块

### 用户管理
- 用户注册
- 用户登录/退出
- 个人信息管理
- 密码修改

### 商品管理
- 商品发布
- 商品编辑
- 商品下架
- 商品分类
- 商品搜索

### 订单管理
- 创建订单
- 订单支付
- 订单状态跟踪
- 订单历史

### 系统管理
- 用户管理（管理员）
- 商品审核
- 系统统计

## 数据库设计

### 主要数据表

- **users**：用户信息表
- **goods**：商品信息表
- **categories**：商品分类表
- **orders**：订单信息表

### 视图

- **user_goods_view**：用户商品视图
- **order_detail_view**：订单详情视图

## 开发指南

### 添加新功能

1. 在 `entity` 包中创建实体类
2. 在 `dao` 包中创建数据访问接口
3. 在 `resources/mapper` 中创建MyBatis映射文件
4. 在 `service` 包中创建服务接口和实现
5. 在 `controller` 包中创建控制器
6. 在 `views` 目录中创建JSP页面

### 代码规范

- 使用UTF-8编码
- 遵循Java命名规范
- 添加适当的注释
- 使用统一的代码格式化

## 部署说明

### 生产环境部署

1. **打包应用**
   ```bash
   mvn clean package
   ```

2. **部署到Tomcat**
   - 将生成的 `target/campus-market.war` 复制到Tomcat的webapps目录
   - 启动Tomcat服务器

3. **配置数据库**
   - 确保生产环境的数据库配置正确
   - 执行数据库初始化脚本

### 性能优化

- 配置数据库连接池
- 启用MyBatis缓存
- 使用CDN加速静态资源
- 配置Gzip压缩

## 常见问题

### Q: 启动时出现数据库连接错误？
A: 检查 `database.properties` 中的数据库配置是否正确，确保MySQL服务正在运行。

### Q: 页面显示乱码？
A: 确保所有文件都使用UTF-8编码，检查数据库字符集设置。

### Q: 静态资源无法访问？
A: 检查 `spring-mvc.xml` 中的静态资源映射配置。

## 贡献指南

1. Fork 项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开 Pull Request

## 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 联系方式

- 项目维护者：[Ye 翔]
- 邮箱：[2369949401@qq.com]
- 项目地址：[https://github.com/flavour0906/campus-market]

## 更新日志

- 初始版本发布
- 实现基本的用户管理功能
- 实现商品管理功能
- 实现订单管理功能 