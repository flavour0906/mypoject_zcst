package controller;

import entity.Goods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import service.GoodsService;

import java.util.ArrayList;
import java.util.List;

@Controller
public class IndexController {
    
    @Autowired
    private GoodsService goodsService;
    
    /**
     * 首页
     */
    @GetMapping({"/", "/index"})
    public String index(Model model) {
        try {
            // 获取热门商品列表，可以根据需求调整，例如获取最新发布的几个
            List<Goods> goodsList = goodsService.getAllGoods();
            model.addAttribute("goodsList", goodsList);
        } catch (Exception e) {
            // 记录日志，并向前端传递错误信息
            System.err.println("首页获取商品列表失败: " + e.getMessage());
            model.addAttribute("error", "加载热门商品失败，请稍后重试或联系管理员。");
            // 即使出错，也返回一个空列表，避免JSP页面出错
            model.addAttribute("goodsList", new ArrayList<Goods>());
        }
        return "index";
    }
} 