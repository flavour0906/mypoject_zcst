package controller;

import entity.Goods;
import entity.Order;
import entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import service.GoodsService;
import service.OrderService;

import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private GoodsService goodsService;

    /**
     * 创建订单
     */
    @PostMapping("/create")
    public String createOrder(@RequestParam Integer goodsId,
                              @RequestParam(defaultValue = "1") Integer quantity,
                              HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/user/login";
        }

        Goods goods = goodsService.getGoodsById(goodsId);
        if (goods == null || goods.getStatus() != 1) { // 1表示上架状态
            return "redirect:/goods/list";
        }

        // 创建订单
        Order order = new Order();
        order.setOrderNumber(UUID.randomUUID().toString().replace("-", ""));
        order.setBuyerId(user.getId());
        order.setSellerId(goods.getSellerId());
        order.setGoodsId(goodsId);
        order.setPrice(goods.getPrice());
        order.setStatus(0); // 0表示待支付
        order.setCreateTime(new Date());
        order.setUpdateTime(new Date());

        boolean result = orderService.createOrder(order);
        if (result) {
            return "redirect:/order/detail/" + order.getId();
        } else {
            // 如果创建失败，重定向回商品详情页
            return "redirect:/goods/detail/" + goodsId;
        }
    }

    /**
     * 订单详情
     */
    @GetMapping("/detail/{id}")
    public String orderDetail(@PathVariable Integer id, Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/user/login";
        }

        Order order = orderService.getOrderById(id);
        if (order == null || (!order.getBuyerId().equals(user.getId()) && !order.getSellerId().equals(user.getId()))) {
            return "redirect:/order/list";
        }

        Goods goods = goodsService.getGoodsById(order.getGoodsId());
        model.addAttribute("order", order);
        model.addAttribute("goods", goods);
        return "order/detail";
    }

    /**
     * 我的订单列表
     */
    @GetMapping({"/list", "/my"})
    public String orderList(@RequestParam(required = false, defaultValue = "0") Integer status,
                            HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/user/login";
        }

        List<Order> orderList = orderService.getOrdersByUserId(user.getId());
        
        // 为每个订单添加商品信息
        for (Order order : orderList) {
            try {
                Goods goods = goodsService.getGoodsById(order.getGoodsId());
                // 使用反射设置goods字段，或者创建一个包装类
                // 这里我们创建一个简单的Map来存储商品信息
                order.setGoods(goods);
            } catch (Exception e) {
                // 如果获取商品信息失败，继续处理其他订单
                System.err.println("获取订单商品信息失败: " + e.getMessage());
            }
        }
        
        model.addAttribute("orderList", orderList);
        return "order/list";
    }

    /**
     * 卖家订单列表
     */
    @GetMapping("/seller/list")
    public String sellerOrderList(@RequestParam(required = false, defaultValue = "0") Integer status,
                                  HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/user/login";
        }

        List<Order> orderList = orderService.getOrdersBySellerId(user.getId());
        model.addAttribute("orderList", orderList);
        return "order/sellerList";
    }

    /**
     * 支付订单
     */
    @GetMapping("/pay/{id}")
    public String payOrder(@PathVariable Integer id, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/user/login";
        }

        Order order = orderService.getOrderById(id);
        if (order == null || !order.getBuyerId().equals(user.getId()) || order.getStatus() != 0) {
            return "redirect:/order/list";
        }

        boolean result = orderService.updateOrderStatus(id, 1); // 1表示已支付
        return "redirect:/order/detail/" + id;
    }

    /**
     * 确认收货
     */
    @GetMapping("/confirm/{id}")
    public String confirmOrder(@PathVariable Integer id, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/user/login";
        }

        Order order = orderService.getOrderById(id);
        if (order == null || !order.getBuyerId().equals(user.getId()) || order.getStatus() != 2) {
            return "redirect:/order/list";
        }

        boolean result = orderService.updateOrderStatus(id, 3); // 3表示已收货
        return "redirect:/order/detail/" + id;
    }

    /**
     * 取消订单
     */
    @GetMapping("/cancel/{id}")
    public String cancelOrder(@PathVariable Integer id, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/user/login";
        }

        Order order = orderService.getOrderById(id);
        if (order == null || (!order.getBuyerId().equals(user.getId()) && !order.getSellerId().equals(user.getId()))) {
            return "redirect:/order/list";
        }

        boolean result = orderService.cancelOrder(id);
        return "redirect:/order/detail/" + id;
    }

    /**
     * 发货
     */
    @GetMapping("/ship/{id}")
    public String shipOrder(@PathVariable Integer id, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/user/login";
        }

        Order order = orderService.getOrderById(id);
        if (order == null || !order.getSellerId().equals(user.getId()) || order.getStatus() != 1) {
            return "redirect:/order/seller/list";
        }

        boolean result = orderService.updateOrderStatus(id, 2); // 2表示已发货
        return "redirect:/order/detail/" + id;
    }
}    