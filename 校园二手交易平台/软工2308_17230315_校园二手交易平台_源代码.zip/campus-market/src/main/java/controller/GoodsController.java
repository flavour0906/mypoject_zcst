package controller;

import entity.Goods;
import entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/goods")
public class GoodsController {

    @Autowired
    private service.GoodsService goodsService;

    /**
     * 商品列表
     */
    @GetMapping("/list")
    public String goodsList(Model model) {
        try {
            List<Goods> goodsList = goodsService.getAllGoods();
            model.addAttribute("goodsList", goodsList);
            return "goods/list";
        } catch (Exception e) {
            model.addAttribute("error", "获取商品列表失败");
            return "goods/list";
        }
    }

    /**
     * 搜索商品
     */
    @GetMapping("/search")
    public String searchGoods(@RequestParam(value = "keyword", required = false) String keyword,
                             @RequestParam(value = "categoryId", required = false) Integer categoryId,
                             @RequestParam(value = "minPrice", required = false) Double minPrice,
                             @RequestParam(value = "maxPrice", required = false) Double maxPrice,
                             @RequestParam(value = "sortBy", defaultValue = "createTime") String sortBy,
                             @RequestParam(value = "sortOrder", defaultValue = "desc") String sortOrder,
                             Model model) {
        try {
            List<Goods> goodsList;
            
            // 如果有高级搜索参数，使用综合搜索
            if ((minPrice != null || maxPrice != null) && (keyword != null || categoryId != null)) {
                goodsList = goodsService.searchGoodsAdvanced(keyword, categoryId, minPrice, maxPrice, sortBy, sortOrder);
            }
            // 如果只有分类搜索
            else if (categoryId != null) {
                goodsList = goodsService.searchGoodsByCategory(keyword, categoryId);
            }
            // 如果只有价格范围搜索
            else if (minPrice != null || maxPrice != null) {
                goodsList = goodsService.searchGoodsByPriceRange(minPrice, maxPrice);
            }
            // 基础关键词搜索
            else {
                goodsList = goodsService.searchGoods(keyword);
            }
            
            model.addAttribute("goodsList", goodsList);
            model.addAttribute("keyword", keyword);
            model.addAttribute("categoryId", categoryId);
            model.addAttribute("minPrice", minPrice);
            model.addAttribute("maxPrice", maxPrice);
            model.addAttribute("sortBy", sortBy);
            model.addAttribute("sortOrder", sortOrder);
            
            return "goods/list";
        } catch (Exception e) {
            model.addAttribute("error", "搜索商品失败：" + e.getMessage());
            return "goods/list";
        }
    }

    /**
     * 商品详情
     */
    @GetMapping("/detail/{id}")
    public String goodsDetail(@PathVariable Integer id, Model model) {
        try {
            Goods goods = goodsService.getGoodsById(id);
            if (goods == null) {
                model.addAttribute("error", "商品不存在");
                return "goods/detail";
            }
            model.addAttribute("goods", goods);
            return "goods/detail";
        } catch (Exception e) {
            model.addAttribute("error", "获取商品详情失败");
            return "goods/detail";
        }
    }

    /**
     * 发布商品页面
     */
    @GetMapping("/add")
    public String addGoodsPage(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/user/login";
        }
        return "goods/add";
    }

    /**
     * 发布商品处理
     */
    @PostMapping("/add")
    public String addGoods(@ModelAttribute Goods goods, HttpSession session, Model model) {
        try {
            User user = (User) session.getAttribute("user");
            if (user == null) {
                return "redirect:/user/login";
            }

            goods.setSellerId(user.getId());
            goods.setStatus(1); // 1表示上架状态

            boolean result = goodsService.addGoods(goods);
            if (result) {
                return "redirect:/goods/list";
            } else {
                model.addAttribute("error", "发布商品失败");
                return "goods/add";
            }
        } catch (Exception e) {
            model.addAttribute("error", "发布商品失败：" + e.getMessage());
            return "goods/add";
        }
    }

    /**
     * 我的商品列表
     */
    @GetMapping("/my")
    public String myGoods(HttpSession session, Model model) {
        try {
            User user = (User) session.getAttribute("user");
            if (user == null) {
                return "redirect:/user/login";
            }

            // 这里调用 getGoodsBySellerId，它不过滤商品状态
            List<Goods> goodsList = goodsService.getGoodsBySellerId(user.getId());
            model.addAttribute("goodsList", goodsList);
            return "goods/my";
        } catch (Exception e) {
            model.addAttribute("error", "获取我的商品失败: " + e.getMessage());
            // 即使出错也返回页面，并显示错误信息
            model.addAttribute("goodsList", new ArrayList<Goods>());
            return "goods/my";
        }
    }

    /**
     * 编辑商品页面
     */
    @GetMapping("/edit/{id}")
    public String editGoodsPage(@PathVariable Integer id, HttpSession session, Model model) {
        try {
            User user = (User) session.getAttribute("user");
            if (user == null) {
                return "redirect:/user/login";
            }

            Goods goods = goodsService.getGoodsById(id);
            if (goods == null || !goods.getSellerId().equals(user.getId())) {
                return "redirect:/goods/my";
            }

            model.addAttribute("goods", goods);
            return "goods/edit";
        } catch (Exception e) {
            return "redirect:/goods/my";
        }
    }

    /**
     * 编辑商品处理
     */
    @PostMapping("/edit")
    public String editGoods(@ModelAttribute Goods goods, HttpSession session, Model model) {
        try {
            User user = (User) session.getAttribute("user");
            if (user == null) {
                return "redirect:/user/login";
            }

            Goods existingGoods = goodsService.getGoodsById(goods.getId());
            if (existingGoods == null || !existingGoods.getSellerId().equals(user.getId())) {
                return "redirect:/goods/my";
            }

            goods.setSellerId(user.getId());
            boolean result = goodsService.updateGoods(goods);
            if (result) {
                return "redirect:/goods/my";
            } else {
                model.addAttribute("error", "更新商品失败");
                return "goods/edit";
            }
        } catch (Exception e) {
            model.addAttribute("error", "更新商品失败：" + e.getMessage());
            return "goods/edit";
        }
    }

    /**
     * 下架商品
     */
    @GetMapping("/off/{id}")
    public String offGoods(@PathVariable Integer id, HttpSession session) {
        try {
            User user = (User) session.getAttribute("user");
            if (user == null) {
                return "redirect:/user/login";
            }

            Goods goods = goodsService.getGoodsById(id);
            if (goods == null || !goods.getSellerId().equals(user.getId())) {
                return "redirect:/goods/my";
            }

            goods.setStatus(0); // 0表示下架
            goodsService.updateGoods(goods);
            return "redirect:/goods/my";
        } catch (Exception e) {
            return "redirect:/goods/my";
        }
    }

    /**
     * 上架商品
     */
    @GetMapping("/on/{id}")
    public String onGoods(@PathVariable Integer id, HttpSession session) {
        try {
            User user = (User) session.getAttribute("user");
            if (user == null) {
                return "redirect:/user/login";
            }

            Goods goods = goodsService.getGoodsById(id);
            if (goods == null || !goods.getSellerId().equals(user.getId())) {
                return "redirect:/goods/my";
            }

            goods.setStatus(1); // 1表示上架
            goodsService.updateGoods(goods);
            return "redirect:/goods/my";
        } catch (Exception e) {
            return "redirect:/goods/my";
        }
    }
} 