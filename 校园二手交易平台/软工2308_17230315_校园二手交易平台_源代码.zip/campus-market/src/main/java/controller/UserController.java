package controller;

import entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import service.UserService;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    /**
     * 用户登录页面
     */
    @GetMapping("/login")
    public String loginPage() {
        return "user/login";
    }

    /**
     * 用户登录处理
     */
    @PostMapping("/login")
    public String login(@RequestParam String username,
                        @RequestParam String password,
                        HttpSession session,
                        Model model) {
        try {
        User user = userService.login(username, password);
        if (user != null) {
            session.setAttribute("user", user);
            return "redirect:/index";
        } else {
            model.addAttribute("error", "用户名或密码错误");
                return "user/login";
            }
        } catch (Exception e) {
            model.addAttribute("error", "系统错误：数据库连接失败，请检查数据库服务是否正常运行");
            return "user/login";
        }
    }

    /**
     * 用户注册页面
     */
    @GetMapping("/register")
    public String registerPage() {
        return "user/register";
    }

    /**
     * 用户注册处理
     */
    @PostMapping("/register")
    public String register(@ModelAttribute User user, Model model) {
        try {
        if (userService.checkUsernameExists(user.getUsername())) {
            model.addAttribute("error", "用户名已存在");
            return "user/register";
        }
            
            // 设置默认值
            user.setRole(0); // 普通用户
            user.setStatus(1); // 启用状态
            
        boolean result = userService.registerUser(user);
        if (result) {
            return "redirect:/user/login";
        } else {
            model.addAttribute("error", "注册失败，请重试");
                return "user/register";
            }
        } catch (Exception e) {
            model.addAttribute("error", "系统错误：数据库连接失败，请检查数据库服务是否正常运行");
            return "user/register";
        }
    }

    /**
     * 用户退出登录
     */
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.removeAttribute("user");
        return "redirect:/index";
    }

    /**
     * 用户个人中心
     */
    @GetMapping("/profile")
    public String profile(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/user/login";
        }
        User currentUser = userService.getUserById(user.getId());
        model.addAttribute("user", currentUser);
        return "user/profile";
    }

    /**
     * 更新用户信息页面
     */
    @GetMapping("/edit")
    public String editProfile(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/user/login";
        }
        User currentUser = userService.getUserById(user.getId());
        model.addAttribute("user", currentUser);
        return "user/edit";
    }

    /**
     * 更新用户信息处理
     */
    @PostMapping("/update")
    public String updateProfile(@ModelAttribute User user, HttpSession session) {
        User currentUser = (User) session.getAttribute("user");
        if (currentUser == null) {
            return "redirect:/user/login";
        }
        user.setId(currentUser.getId());
        boolean result = userService.updateUser(user);
        if (result) {
            // 更新session中的用户信息
            User updatedUser = userService.getUserById(user.getId());
            session.setAttribute("user", updatedUser);
            return "redirect:/user/profile";
        } else {
            return "redirect:/user/edit";
        }
    }

    /**
     * 管理员查看所有用户
     */
    @GetMapping("/list")
    public String listUsers(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null || user.getRole() != 1) { // 1表示管理员
            return "redirect:/index";
        }
        List<User> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "admin/userList";
    }
}    