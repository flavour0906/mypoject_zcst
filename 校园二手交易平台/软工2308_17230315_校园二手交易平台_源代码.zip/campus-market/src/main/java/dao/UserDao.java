package dao;

import entity.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserDao {
    /**
     * 根据ID查询用户
     */
    User queryById(Integer id);

    /**
     * 根据用户名查询用户
     */
    User queryByUsername(String username);

    /**
     * 查询所有用户
     */
    List<User> queryAll();

    /**
     * 新增用户
     */
    int insert(User user);

    /**
     * 更新用户信息
     */
    int update(User user);

    /**
     * 删除用户
     */
    int deleteById(Integer id);

    /**
     * 用户登录验证
     */
    User login(@Param("username") String username, @Param("password") String password);
}    