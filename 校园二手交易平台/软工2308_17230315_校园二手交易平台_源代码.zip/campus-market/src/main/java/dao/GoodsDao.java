package dao;

import entity.Goods;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface GoodsDao {
    
    /**
     * 根据ID查询商品
     */
    Goods queryById(Integer id);
    
    /**
     * 查询所有商品
     */
    List<Goods> queryAll();
    
    /**
     * 根据分类ID查询商品
     */
    List<Goods> queryByCategoryId(Integer categoryId);
    
    /**
     * 根据卖家ID查询商品
     */
    List<Goods> queryBySellerId(Integer sellerId);
    
    /**
     * 分页查询商品
     */
    List<Goods> queryByPage(@Param("offset") int offset, @Param("pageSize") int pageSize);
    
    /**
     * 搜索商品（按名称和描述）
     */
    List<Goods> searchGoods(@Param("keyword") String keyword);
    
    /**
     * 按分类搜索商品
     */
    List<Goods> searchGoodsByCategory(@Param("keyword") String keyword, @Param("categoryId") Integer categoryId);
    
    /**
     * 按价格范围搜索商品
     */
    List<Goods> searchGoodsByPriceRange(@Param("minPrice") Double minPrice, @Param("maxPrice") Double maxPrice);
    
    /**
     * 综合搜索商品
     */
    List<Goods> searchGoodsAdvanced(@Param("keyword") String keyword, 
                                   @Param("categoryId") Integer categoryId,
                                   @Param("minPrice") Double minPrice, 
                                   @Param("maxPrice") Double maxPrice,
                                   @Param("sortBy") String sortBy,
                                   @Param("sortOrder") String sortOrder);
    
    /**
     * 插入商品
     */
    int insert(Goods goods);
    
    /**
     * 更新商品
     */
    int update(Goods goods);
    
    /**
     * 根据ID删除商品
     */
    int deleteById(Integer id);
} 