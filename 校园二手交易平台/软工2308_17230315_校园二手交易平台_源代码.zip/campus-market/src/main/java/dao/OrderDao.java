package dao;

import entity.Order;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderDao {
    /**
     * 根据ID查询订单
     */
    Order queryById(Integer id);

    /**
     * 根据订单号查询订单
     */
    Order queryByOrderNumber(String orderNumber);

    /**
     * 查询用户的所有订单
     */
    List<Order> queryByUserId(Integer userId);

    /**
     * 查询卖家的所有订单
     */
    List<Order> queryBySellerId(Integer sellerId);

    /**
     * 新增订单
     */
    int insert(Order order);

    /**
     * 更新订单信息
     */
    int update(Order order);

    /**
     * 删除订单
     */
    int deleteById(Integer id);

    /**
     * 分页查询订单
     */
    List<Order> queryByPage(@Param("offset") int offset, @Param("limit") int limit);
}    