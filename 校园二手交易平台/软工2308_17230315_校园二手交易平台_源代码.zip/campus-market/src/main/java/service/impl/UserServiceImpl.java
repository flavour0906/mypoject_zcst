package service.impl;

import dao.UserDao;
import entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import service.UserService;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    @Override
    public User getUserById(Integer id) {
        return userDao.queryById(id);
    }

    @Override
    public List<User> getAllUsers() {
        return userDao.queryAll();
    }

    @Override
    @Transactional
    public boolean registerUser(User user) {
        // 检查用户名是否已存在
        if (checkUsernameExists(user.getUsername())) {
            return false;
        }
        // 插入用户数据
        int result = userDao.insert(user);
        return result > 0;
    }

    @Override
    public User login(String username, String password) {
        return userDao.login(username, password);
    }

    @Override
    @Transactional
    public boolean updateUser(User user) {
        int result = userDao.update(user);
        return result > 0;
    }

    @Override
    @Transactional
    public boolean deleteUser(Integer id) {
        int result = userDao.deleteById(id);
        return result > 0;
    }

    @Override
    public boolean checkUsernameExists(String username) {
        User user = userDao.queryByUsername(username);
        return user != null;
    }
}    