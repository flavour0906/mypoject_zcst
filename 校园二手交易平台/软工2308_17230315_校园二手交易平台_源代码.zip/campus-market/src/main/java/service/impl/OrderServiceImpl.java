package service.impl;

import dao.OrderDao;
import entity.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import service.OrderService;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderDao orderDao;

    @Override
    public Order getOrderById(Integer id) {
        return orderDao.queryById(id);
    }

    @Override
    public Order getOrderByOrderNumber(String orderNumber) {
        return orderDao.queryByOrderNumber(orderNumber);
    }

    @Override
    public List<Order> getOrdersByUserId(Integer userId) {
        return orderDao.queryByUserId(userId);
    }

    @Override
    public List<Order> getOrdersBySellerId(Integer sellerId) {
        return orderDao.queryBySellerId(sellerId);
    }

    @Override
    @Transactional
    public boolean createOrder(Order order) {
        int result = orderDao.insert(order);
        return result > 0;
    }

    @Override
    @Transactional
    public boolean updateOrderStatus(Integer orderId, Integer status) {
        Order order = orderDao.queryById(orderId);
        if (order == null) {
            return false;
        }
        order.setStatus(status);
        int result = orderDao.update(order);
        return result > 0;
    }

    @Override
    @Transactional
    public boolean cancelOrder(Integer orderId) {
        return updateOrderStatus(orderId, 4); // 4表示已取消
    }

    @Override
    public List<Order> getOrdersByPage(int pageNum, int pageSize) {
        int offset = (pageNum - 1) * pageSize;
        return orderDao.queryByPage(offset, pageSize);
    }
}    