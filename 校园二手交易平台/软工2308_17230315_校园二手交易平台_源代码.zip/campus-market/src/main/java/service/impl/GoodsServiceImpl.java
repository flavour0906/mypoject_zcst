package service.impl;

import dao.GoodsDao;
import entity.Goods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import service.GoodsService;

import java.util.List;

@Service
public class GoodsServiceImpl implements GoodsService {

    @Autowired
    private GoodsDao goodsDao;

    @Override
    public Goods getGoodsById(Integer id) {
        return goodsDao.queryById(id);
    }

    @Override
    public List<Goods> getAllGoods() {
        return goodsDao.queryAll();
    }

    @Override
    public List<Goods> getGoodsByCategoryId(Integer categoryId) {
        return goodsDao.queryByCategoryId(categoryId);
    }

    @Override
    public List<Goods> getGoodsBySellerId(Integer sellerId) {
        return goodsDao.queryBySellerId(sellerId);
    }

    @Override
    public List<Goods> getGoodsByPage(int pageNum, int pageSize) {
        int offset = (pageNum - 1) * pageSize;
        return goodsDao.queryByPage(offset, pageSize);
    }

    @Override
    public List<Goods> searchGoods(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllGoods();
        }
        return goodsDao.searchGoods(keyword.trim());
    }

    @Override
    public List<Goods> searchGoodsByCategory(String keyword, Integer categoryId) {
        if (categoryId == null) {
            return searchGoods(keyword);
        }
        if (keyword == null || keyword.trim().isEmpty()) {
            return getGoodsByCategoryId(categoryId);
        }
        return goodsDao.searchGoodsByCategory(keyword.trim(), categoryId);
    }

    @Override
    public List<Goods> searchGoodsByPriceRange(Double minPrice, Double maxPrice) {
        if (minPrice == null && maxPrice == null) {
            return getAllGoods();
        }
        if (minPrice == null) minPrice = 0.0;
        if (maxPrice == null) maxPrice = Double.MAX_VALUE;
        return goodsDao.searchGoodsByPriceRange(minPrice, maxPrice);
    }

    @Override
    public List<Goods> searchGoodsAdvanced(String keyword, Integer categoryId, 
                                          Double minPrice, Double maxPrice, 
                                          String sortBy, String sortOrder) {
        // 参数验证和默认值设置
        if (keyword != null && keyword.trim().isEmpty()) {
            keyword = null;
        }
        if (minPrice != null && minPrice < 0) {
            minPrice = 0.0;
        }
        if (maxPrice != null && maxPrice < 0) {
            maxPrice = null;
        }
        if (sortBy == null || sortBy.trim().isEmpty()) {
            sortBy = "createTime";
        }
        if (sortOrder == null || sortOrder.trim().isEmpty()) {
            sortOrder = "desc";
        }
        
        return goodsDao.searchGoodsAdvanced(keyword, categoryId, minPrice, maxPrice, sortBy, sortOrder);
    }

    @Override
    @Transactional
    public boolean addGoods(Goods goods) {
        int result = goodsDao.insert(goods);
        return result > 0;
    }

    @Override
    @Transactional
    public boolean updateGoods(Goods goods) {
        int result = goodsDao.update(goods);
        return result > 0;
    }

    @Override
    @Transactional
    public boolean deleteGoods(Integer id) {
        int result = goodsDao.deleteById(id);
        return result > 0;
    }
}    