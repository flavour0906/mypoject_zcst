package service;

import entity.Order;

import java.util.List;

public interface OrderService {
    /**
     * 根据ID获取订单
     */
    Order getOrderById(Integer id);

    /**
     * 根据订单号获取订单
     */
    Order getOrderByOrderNumber(String orderNumber);

    /**
     * 获取用户的所有订单
     */
    List<Order> getOrdersByUserId(Integer userId);

    /**
     * 获取卖家的所有订单
     */
    List<Order> getOrdersBySellerId(Integer sellerId);

    /**
     * 创建订单
     */
    boolean createOrder(Order order);

    /**
     * 更新订单状态
     */
    boolean updateOrderStatus(Integer orderId, Integer status);

    /**
     * 取消订单
     */
    boolean cancelOrder(Integer orderId);

    /**
     * 分页获取订单
     */
    List<Order> getOrdersByPage(int pageNum, int pageSize);
}    