package service;

import entity.User;

import java.util.List;

public interface UserService {
    /**
     * 根据ID获取用户
     */
    User getUserById(Integer id);

    /**
     * 获取所有用户
     */
    List<User> getAllUsers();

    /**
     * 注册用户
     */
    boolean registerUser(User user);

    /**
     * 用户登录
     */
    User login(String username, String password);

    /**
     * 更新用户信息
     */
    boolean updateUser(User user);

    /**
     * 删除用户
     */
    boolean deleteUser(Integer id);

    /**
     * 检查用户名是否存在
     */
    boolean checkUsernameExists(String username);
}    