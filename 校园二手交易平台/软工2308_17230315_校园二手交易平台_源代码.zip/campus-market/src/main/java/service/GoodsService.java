package service;

import entity.Goods;

import java.util.List;

public interface GoodsService {
    /**
     * 根据ID获取商品
     */
    Goods getGoodsById(Integer id);

    /**
     * 获取所有商品
     */
    List<Goods> getAllGoods();

    /**
     * 根据分类ID获取商品
     */
    List<Goods> getGoodsByCategoryId(Integer categoryId);

    /**
     * 根据卖家ID获取商品
     */
    List<Goods> getGoodsBySellerId(Integer sellerId);

    /**
     * 分页获取商品
     */
    List<Goods> getGoodsByPage(int pageNum, int pageSize);

    /**
     * 搜索商品
     */
    List<Goods> searchGoods(String keyword);

    /**
     * 按分类搜索商品
     */
    List<Goods> searchGoodsByCategory(String keyword, Integer categoryId);

    /**
     * 按价格范围搜索商品
     */
    List<Goods> searchGoodsByPriceRange(Double minPrice, Double maxPrice);

    /**
     * 综合搜索商品
     */
    List<Goods> searchGoodsAdvanced(String keyword, Integer categoryId, 
                                   Double minPrice, Double maxPrice, 
                                   String sortBy, String sortOrder);

    /**
     * 添加商品
     */
    boolean addGoods(Goods goods);

    /**
     * 更新商品
     */
    boolean updateGoods(Goods goods);

    /**
     * 删除商品
     */
    boolean deleteGoods(Integer id);
}    