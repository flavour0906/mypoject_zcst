-- 创建数据库（如果不存在）
CREATE DATABASE IF NOT EXISTS campus_trading_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE campus_trading_platform;

-- 删除已存在的表（如果存在）
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS goods;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;

-- 用户表
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    role TINYINT NOT NULL DEFAULT 0 COMMENT '0-普通用户，1-管理员',
    phone VARCHAR(20),
    email VARCHAR(50),
    student_id VARCHAR(20) COMMENT '学号',
    status TINYINT NOT NULL DEFAULT 1 COMMENT '0-禁用，1-启用',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 商品分类表
CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(200),
    parent_id INT DEFAULT NULL,
    status TINYINT NOT NULL DEFAULT 1 COMMENT '0-禁用，1-启用',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 商品表
CREATE TABLE goods (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category_id INT NOT NULL,
    seller_id INT NOT NULL,
    status TINYINT NOT NULL DEFAULT 1 COMMENT '0-下架，1-上架，2-已售出',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id),
    FOREIGN KEY (seller_id) REFERENCES users(id)
);

-- 订单表
CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_number VARCHAR(50) NOT NULL UNIQUE,
    buyer_id INT NOT NULL,
    seller_id INT NOT NULL,
    goods_id INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    status TINYINT NOT NULL DEFAULT 0 COMMENT '0-待支付，1-已支付，2-已发货，3-已收货，4-已取消',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (buyer_id) REFERENCES users(id),
    FOREIGN KEY (seller_id) REFERENCES users(id),
    FOREIGN KEY (goods_id) REFERENCES goods(id)
);

-- 用户商品视图
CREATE VIEW user_goods_view AS
SELECT 
    g.id AS goods_id,
    g.name AS goods_name,
    g.description,
    g.price,
    g.status AS goods_status,
    g.create_time AS goods_create_time,
    s.username AS seller_username,
    s.phone AS seller_phone,
    s.email AS seller_email,
    c.name AS category_name
FROM 
    goods g
JOIN 
    users s ON g.seller_id = s.id
JOIN 
    categories c ON g.category_id = c.id;

-- 订单详情视图
CREATE VIEW order_detail_view AS
SELECT 
    o.id AS order_id,
    o.order_number,
    o.price,
    o.status AS order_status,
    o.create_time AS order_create_time,
    g.name AS goods_name,
    g.description AS goods_description,
    buyer.username AS buyer_username,
    buyer.phone AS buyer_phone,
    seller.username AS seller_username,
    seller.phone AS seller_phone
FROM 
    orders o
JOIN 
    goods g ON o.goods_id = g.id
JOIN 
    users buyer ON o.buyer_id = buyer.id
JOIN 
    users seller ON o.seller_id = seller.id;

-- 插入测试数据
INSERT INTO users (username, password, role, phone, email, student_id) VALUES
('admin', 'admin123', 1, '13800138000', 'admin@example.com', '20230001'),
('user1', 'user123', 0, '13900139000', 'user1@example.com', '20230002'),
('user2', 'user123', 0, '13900139001', 'user2@example.com', '20230003');

INSERT INTO categories (name, description) VALUES
('书籍教材', '各类学习书籍和教材'),
('电子产品', '手机、电脑、平板等电子产品'),
('生活用品', '各类生活用品'),
('服饰鞋帽', '各类服装、鞋子和帽子'),
('运动器材', '各类运动用品和器材');

INSERT INTO goods (name, description, price, category_id, seller_id, status) VALUES
('Java编程思想', '第4版，经典Java学习书籍', 50.00, 1, 2, 1),
('笔记本电脑', '联想ThinkPad，九成新', 3500.00, 2, 2, 1),
('篮球', '斯伯丁篮球，使用一个月', 120.00, 5, 3, 1),
('冬季外套', '黑色羽绒服，九成新', 200.00, 4, 3, 1);

INSERT INTO orders (order_number, buyer_id, seller_id, goods_id, price, status) VALUES
('202506210001', 3, 2, 1, 50.00, 1),
('202506210002', 2, 3, 3, 120.00, 0); 