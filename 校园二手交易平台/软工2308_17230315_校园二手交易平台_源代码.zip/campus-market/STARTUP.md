# 校园二手交易平台 - 启动指南

## 🚀 快速启动

### 1. 环境要求
- JDK 1.8+
- Maven 3.6+
- MySQL 8.0+

### 2. 数据库配置
1. 启动MySQL服务
2. 执行数据库初始化脚本：
   ```sql
   -- 方法1：使用提供的脚本
   mysql -u root -p < src/main/resources/init.sql
   
   -- 方法2：手动创建数据库
   CREATE DATABASE campus_trading_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

3. 修改数据库连接配置（如果需要）：
   - 文件：`src/main/resources/database.properties`
   - 修改：username、password

### 3. 启动应用

#### 方法一：使用Maven插件（推荐）
```bash
# 编译项目
mvn clean compile

# 启动应用
mvn tomcat7:run
```

#### 方法二：使用IDEA
1. 配置Tomcat服务器
2. 设置Deployment的Application context为：`/campus_market_war_exploded`
3. 启动项目

### 4. 访问应用
- **首页**：http://localhost:8080/campus_market_war_exploded/
- **测试页面**：http://localhost:8080/campus_market_war_exploded/test
- **健康检查**：http://localhost:8080/campus_market_war_exploded/health

### 5. 默认账户
- **管理员**：admin / admin123
- **普通用户1**：user1 / user123
- **普通用户2**：user2 / user123

## 🔧 常见问题

### Q1: 404错误
**原因**：访问路径不正确
**解决**：确保访问 `/campus_market_war_exploded/` 而不是 `/campus-market/`

### Q2: 数据库连接失败
**原因**：MySQL未启动或配置错误
**解决**：
1. 检查MySQL服务是否启动
2. 检查 `database.properties` 配置
3. 确保数据库 `campus_trading_platform` 已创建

### Q3: 编译失败
**原因**：依赖下载失败或JDK版本不匹配
**解决**：
1. 检查网络连接
2. 确保JDK版本为1.8+
3. 清理Maven缓存：`mvn clean`

### Q4: 端口被占用
**原因**：8080端口已被其他应用占用
**解决**：
1. 修改 `pom.xml` 中的端口配置
2. 或停止占用端口的应用

## 📁 项目结构
```
campus-market/
├── src/main/java/
│   ├── controller/          # 控制器层
│   ├── service/             # 服务层
│   ├── dao/                 # 数据访问层
│   └── entity/              # 实体类
├── src/main/resources/
│   ├── mapper/              # MyBatis映射文件
│   ├── applicationContext.xml  # Spring配置
│   ├── spring-mvc.xml       # Spring MVC配置
│   ├── database.properties  # 数据库配置
│   └── logback.xml          # 日志配置
└── src/main/webapp/
    ├── WEB-INF/
    │   ├── views/           # JSP视图文件
    │   └── web.xml          # Web应用配置
    └── index.jsp            # 首页重定向
```

## 🎯 功能测试

### 1. 基础功能测试
- [x] 访问首页：http://localhost:8080/campus_market_war_exploded/
- [x] 用户登录：http://localhost:8080/campus_market_war_exploded/user/login
- [x] 用户注册：http://localhost:8080/campus_market_war_exploded/user/register

### 2. 用户功能测试
- [x] 登录：admin/admin123
- [x] 查看个人中心：/user/profile
- [x] 编辑个人信息：/user/edit

### 3. 商品功能测试
- [x] 查看商品列表：/goods/list
- [x] 查看商品详情：/goods/detail/{id}

## 📝 开发说明

### 添加新功能
1. 在 `entity` 包中创建实体类
2. 在 `dao` 包中创建数据访问接口
3. 在 `resources/mapper` 中创建MyBatis映射文件
4. 在 `service` 包中创建服务接口和实现
5. 在 `controller` 包中创建控制器
6. 在 `views` 目录中创建JSP页面

### 代码规范
- 使用UTF-8编码
- 遵循Java命名规范
- 添加适当的注释
- 使用统一的代码格式化

## 🆘 技术支持

如果遇到问题，请检查：
1. 控制台日志输出
2. 数据库连接状态
3. 网络连接状态
4. 端口占用情况

项目已完全配置好，可以直接运行！ 